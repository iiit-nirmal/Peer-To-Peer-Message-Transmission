/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mychatappp.networking;

import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nirmal
 */
public class MessageTransmitter extends Thread {
        
 String message,hostman;
 int port;
   
public MessageTransmitter(){
        
}

public MessageTransmitter(String message,String hostman,int port){
             this.message=message;
             this.hostman=hostman;
             this.port=port;
}

public void run(){
     try {
         Socket s=new Socket(hostman,port);
         s.getOutputStream().write(message.getBytes());
         s.close();
     } catch (IOException ex) {
         Logger.getLogger(MessageTransmitter.class.getName()).log(Level.SEVERE, null, ex);
     }
       
}



}
