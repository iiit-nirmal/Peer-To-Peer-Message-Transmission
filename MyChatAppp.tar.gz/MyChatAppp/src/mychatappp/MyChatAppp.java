
package mychatappp;

import mychatappp.gui.MyScreen;

public class MyChatAppp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyScreen screen=new MyScreen();
        screen.show();
    }
    
}
